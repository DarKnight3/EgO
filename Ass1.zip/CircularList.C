#include "CircularList.h"
 
/*
Provide all of the implementation for the CircularList
class in this file
*/

CircularList& CircularList::operator=(const CircularList& other){
	Node* cur = other.tail;
	
	int x = -1;
	
	while ((other.tail != cur) || (x == -1)){
		addToFront(cur);
		x++;
	}
	
	return this;
}

ostream& operator<<(ostream& os,CircularList& c){
	if (c.tail == NULL)
		os << "[]";
	else
		os << *c.tail;
	
	return os;
}

void CircularList::addToFront(int elem){
	if (elem > -1){
		Node* cur = new Node(elem, NULL);
	
		if (tail == NULL){
			cur.next = tail;
			tail = cur;
		}else{
			cur.next = tail.next;
			tail.next = cur;
		}
	}
}

int CircularList::deleteFromBack(){
	if (tail == NULL)
		return -1;
	else{
		int res;
		
		if (tail == tail->next)
			res = tail->data;
			delete tail;
		else{
			Node* cur = tail;
			
			while (cur.next != tail)
				cur = cur->next;
			
			cur->next = tail->next;
			res = tail->data;
			
			delete tail;
			
			tail = cur;
			
		}
		
		return res;
	}
}
