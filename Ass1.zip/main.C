#include "Deque.h"

/*
Write all of your test code in this file. You may
modify the contents in this file in any way
you need to in order to assist you in completing
the assignment.
*/
 
int main()
{
	
	
	return 0;
}
