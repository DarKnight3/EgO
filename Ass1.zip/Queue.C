#include "Queue.h"
 
 /*
Provide all of the implementation for the Queue
class in this file
 */

Queue& Queue::operator=(const Queue& other){
	Stack* cur = other.stack;
	
	stack = new Stack();
	
	while (other.stack->isEmpty() == false){
		int elem = other.stack->pop();
		enqueue(elem);
	}
	
	return this;
}

ostream& operator<<(ostream& os,Queue& c){
	if (c.stack->isEmpty())
		os << "[]";
	else {
		os << "[";
		while (c.stack->isEmpty() == false){
			os << c.stack->pop();
			
			if (c.stack->isEmpty() == false)
				os << ","
		}
		os << "]";
	}
}

void Queue::enqueue(int elem){
	if (elem > -1)
		stack->push(elem);
}



int Queue::dequeue(){
	
	if (isEmpty())
		return -1;
	
	Stack* tmp = new Stack();
	int cur = 0;
	int size = 0;
	int res = 0;
	
	while (stack->isEmpty() == false){
		cur = stack->pop();
		size++;
		
		if (stack.isEmpty() == false)
			tmp->push(cur);
	}
	
	res = cur;
	
	Stack* sptr[size-3];
	
	for (int n = 0; n < size-3; n++)
		sptr[n] = new Stack();
	
	while (tmp->isEmpty() == false){
		cur = tmp->pop();
		sptr[0]->push(cur);
	}	
	
	for (int x = 0; x < n-3; x++){
		
		while (sptr[x]->isEmpty() == false){
			cur = sptr[x]->pop();
			
			if (x+1 < n-3)
				sptr[x+1]->push(cur);
		}
	}
	
	stack = new Stack();
	
	while (sptr[size-4]->isEmpty() == false){
		cur = sptr[size-4]->pop();
		stack->push(cur);
	}	
	
	for (int n = 0; n < size-3; n++)
		delete sptr[n];	
	
	delete tmp;
	
	return res;

}

bool Queue::isEmpty(){return (stack.isEmpty());}

int Queue::front(){
	
	if (isEmpty())
		return -1;
	
	Stack* tmp = new Stack();
	int cur = 0;
	int size = 0;
	int res = 0;
	
	while (stack->isEmpty() == false){
		cur = stack->pop();
		size++;
		
		tmp->push(cur);
	}
	
	res = cur;
	
	Stack* sptr[size-2];
	
	for (int n = 0; n < size-2; n++)
		sptr[n] = new Stack();
	
	while (tmp->isEmpty() == false){
		cur = tmp->pop();
		sptr[0]->push(cur);
	}	
	
	for (int x = 0; x < n-2; x++){
		
		while (sptr[x]->isEmpty() == false){
			cur = sptr[x]->pop();
			
			if (x+1 < n-2)
				sptr[x+1]->push(cur);
		}
	}
	
	stack = new Stack();
	
	while (sptr[size-3]->isEmpty() == false){
		cur = sptr[size-3]->pop();
		stack->push(cur);
	}	
	
	for (int n = 0; n < size-2; n++)
		delete sptr[n];	
	
	delete tmp;
	
	return res;

}