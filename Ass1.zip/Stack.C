#include "Stack.h"
 
 /*
Provide all of the implementation for the Stack
class in this file
 */

Stack& Stack::operator=(const Stack& other){
	list = new CircularList();
	
	int item = other.list->deleteFromBack();
	
	while (item != -1){
		list->addToFront(item);
		item = other.list->deleteFromBack();
	}
	
	return this;
}

ostream& operator<<(ostream& os,Stack& c){
	if (c.isEmpty())
		os << "[]";
	else
		os << *c.list
}

void Stack::push(int elem){
	if (elem > -1)
		list->addToFront(elem);
}

int Stack::pop(){
	if (isEmpty()){
		
		int found = 0;
		int res = 0;
		
		CircularList* temp = new CircularList();
		int item = list->deleteFromBack();
		
		while (item != -1){
			
			res = item
			temp->addToFront(item);
			item = list->deleteFromBack();

		}
		
		item = temp->deleteFromBack();
		while (item != -1){
			
			if ((found != 0) || (item != res))
				list->addToFront(item);
			else if (item == res)
				found++;
			
			item = temp.deleteFromBack();
		}
		
		return res;
		
	}else
		return -1;
}

int Stack::peek(){
	if (isEmpty()){
		
		int res = 0;
		
		CircularList* temp = new CircularList();
		
		int item = list->deleteFromBack();
		
		while (item != -1){
			
			res = item
			temp->addToFront(item);
			item = list->deleteFromBack();

		}
		
		item = temp->deleteFromBack();
		while (item != -1){
			
			list->addToFront(item);
			item = temp.deleteFromBack();
		}
		
		return res;
		
	}else
		return -1;
}

bool Stack::isEmpty(){
	
	bool res = false;
		
	CircularList* temp = new CircularList();
		
	int item = list->deleteFromBack();
		
	if (item == -1)
		res = true;
		
	while (item != -1){
			
		temp->addToFront(item);
		item = list->deleteFromBack();

	}
		
	item = temp->deleteFromBack();
	while (item != -1){
			
		list->addToFront(item);
		item = temp.deleteFromBack();
	}
		
	return res;
		
}

